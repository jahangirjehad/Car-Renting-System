import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:comment_box/comment/comment.dart';
import 'package:detection/Screen/comment-section.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final formKey = GlobalKey<FormState>();
  final TextEditingController commentController = TextEditingController();
  var date;
  var like;
  var detection_label;
  var email;
  var url;
  int _selectedIndex = 0;
  _onSelected(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Widget commentChild(data) {
    return ListView(
      children: [
        for (var i = 0; i < data.length; i++)
          Padding(
            padding: const EdgeInsets.fromLTRB(2.0, 8.0, 2.0, 0.0),
            child: ListTile(
              leading: GestureDetector(
                onTap: () async {
                  // Display the image in large form.
                  print("Comment Clicked");
                },
                child: Container(
                  height: 50.0,
                  width: 50.0,
                  decoration: new BoxDecoration(
                      color: Colors.blue,
                      borderRadius: new BorderRadius.all(Radius.circular(50))),
                  child: CircleAvatar(
                      radius: 50,
                      backgroundImage: CommentBox.commentImageParser(
                          imageURLorPath: data[i]['pic'])),
                ),
              ),
              title: Text(
                data[i]['name'],
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(data[i]['message']),
              trailing: Text(data[i]['date'], style: TextStyle(fontSize: 10)),
            ),
          )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: StreamBuilder(
            stream:
                FirebaseFirestore.instance.collection("detection").snapshots(),
            builder: (BuildContext context, AsyncSnapshot snapshot) {
              var data = snapshot.data;
              if (data == null) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
              return ListView.builder(
                  itemCount: snapshot.data!.docs.length,
                  itemBuilder: (_, index) {
                    DocumentSnapshot _documentSnapshot =
                        snapshot.data!.docs[index];
                    email = _documentSnapshot['email'];
                    date = _documentSnapshot['date'].toDate();
                    detection_label = _documentSnapshot['label'];
                    like = _documentSnapshot['like'];
                    url = _documentSnapshot['img'];
                    var id = _documentSnapshot.id;
                    String datetime = date.year.toString() +
                        "/" +
                        date.month.toString() +
                        "/" +
                        date.day.toString();

                    return Card(
                      //padding: EdgeInsets.all(20),
                      margin: EdgeInsets.only(bottom: 30),
                      color: Colors.white,
                      elevation: 10,
                      child: Column(
                        children: [
                          Container(
                            alignment: Alignment.centerLeft,
                            width: MediaQuery.of(context).size.width * .5,
                            height: 150,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.fill,
                                image:
                                    NetworkImage("${_documentSnapshot['img']}"),
                              ),
                            ),
                          ),
                          Row(
                            children: [
                              Container(
                                margin: EdgeInsets.only(top: 7),
                                //color: Colors.greenAccent,
                                //margin: EdgeInsets.only(bottom: 5),
                                width: MediaQuery.of(context).size.width * .3,
                                height: 40,
                                child: Text(
                                  "Date: ",
                                  style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(left: 10),
                                width: MediaQuery.of(context).size.width * .5,
                                height: 30,
                                child: Text("$datetime"),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Container(
                                margin: EdgeInsets.only(top: 7),
                                //color: Colors.greenAccent,
                                //margin: EdgeInsets.only(bottom: 5),
                                width: MediaQuery.of(context).size.width * .3,
                                height: 40,
                                child: Text(
                                  "Email: ",
                                  style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(left: 10),
                                width: MediaQuery.of(context).size.width * .5,
                                height: 30,
                                child: Text("$email"),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Container(
                                margin: EdgeInsets.only(top: 7),
                                //color: Colors.greenAccent,
                                //margin: EdgeInsets.only(bottom: 5),
                                width: MediaQuery.of(context).size.width * .3,
                                height: 40,
                                child: Text(
                                  "Detection Result: ",
                                  style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(left: 10),
                                width: MediaQuery.of(context).size.width * .5,
                                height: 30,
                                child: Text("$detection_label"),
                              ),
                            ],
                          ),
                          OutlinedButton.icon(
                            // <-- OutlinedButton
                            style: ButtonStyle(),
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) =>
                                      CommentSection(url: id)));
                            },
                            icon: Icon(
                              Icons.comment,
                              size: 24.0,
                            ),
                            label: Text('comment'),
                          ),
                        ],
                      ),
                    );
                  });
            },
          ),
        ),
      )),
    );
  }
}
