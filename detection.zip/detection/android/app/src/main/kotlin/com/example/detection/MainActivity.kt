package com.example.detection

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
